# ONLINE APPOINTMENT FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## Features

Provides an online appointment booking system. This allow anyone to book rendez-vous, according to predefined ranges or availabilities.

<!--
![Screenshot bookcal](img/screenshot_bookcal.png?raw=true "BookCal"){imgmd}
-->
