# PrestaShop-webservice-lib

Source updated from:

https://github.com/PrestaShop/PrestaShop-webservice-lib/blob/master/PSWebServiceLibrary.php

## License compatibility analysis

https://www.gnu.org/licenses/license-list.html#OSL


## Local changes

- Change `executeRequest` to public method because
  `htdocs/admin/dolistore/ajax/image.php#` uses it.

