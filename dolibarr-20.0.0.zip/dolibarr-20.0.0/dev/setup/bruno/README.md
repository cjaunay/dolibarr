= To install Bruno on Ubuntu =
sudo snap install bruno

Then create a project.

Then you can import the definition of all API from Bruno by using the URL provided in Dolibarr API module.
