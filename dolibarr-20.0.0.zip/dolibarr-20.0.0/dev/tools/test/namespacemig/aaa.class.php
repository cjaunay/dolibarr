<?php

namespace Dolibarr;

global $globalaaa;
$globalaaa = 'globalaaa';

/**
 * faaa
 *
 * @return string
 */
function faaa()
{
	return 'faaa';
}

/**
 * Class Aaa
 */
class Aaa
{
	const AAA='aaa';

	/**
	 * do
	 *
	 * @return void
	 */
	public function do()
	{
		echo 'doaaa'."\n";
	}
}
