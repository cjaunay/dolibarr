Test to migrate Dolibarr to namespace "Dolibarr".

Script bbb.php is a script of an external module with current code writing. 
It must works after migration. 